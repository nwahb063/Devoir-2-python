#Auteur: Nabil Wahbi
#Numéro d'étudiant: 300144558
print("Auteur:Nabil Wahbi")
print("Numéro d'étudiant: 300144558")

def palindrome(mot):#on doit mettre les guillemets entre le mot quand on execute la fonction
    mot=mot.lower()
    n=len(mot)
    i=0
    while i<=n//2 and mot[i]==mot[n-i-1]:
        i+=1
    return mot[i]==mot[n-i-1]
    
