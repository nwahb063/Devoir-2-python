#Auteur: Nabil Wahbi
#Numéro d'étudiant: <300144558>
print("Auteur: Nabil Wahbi")
print("numéro d'étudiant:300144558")

def triangle(hauteur):
    nbr_E=1
    nbr_esp=hauteur-1
    
    for i in range(hauteur):
        print(nbr_esp*" "+nbr_E*"*")
        nbr_E+=2
        nbr_esp-=1
     
  
    
