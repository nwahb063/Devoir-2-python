#Auteur: Nabil Wahbi
#Numéro d'étudiant:<300144558>
print("Auteur:Nabil Wahbi")
print("Numéro d'étudiant:3001445583")

nombre=int(input("entrez le nombre de termes: "))

def fibonacci(n):
    A=0
    B=1
    if(n< 2):
        n=int(input("entrez le nombre de termes: "))
    else:
        for i in range(n):
            C=A+B
            print(A, end = " ")
            A=B
            B=C
            i=i+1

fibonacci(nombre)
