#auteur:Nabil Wahbi
#Numéro d'étudiant:<300144558>
print("Auteur:Nabil Wahbi")
print("Numéro d'étudiant:300144558")

#Partie A

def prime_joueur (buts,aides,penalites,annees,matchs):
    print("si votre code de prime est 0, vous n'obtennez pas de prime")
    print("si votre code de prime est 1, vous obtenez une prime conditionnelle")
    print("si votre code de prime est 2, vous obtenez une prime partielle")
    print("si votre code de prime est 3, vous obtenez une prime complete")

    if buts > 20 or aides > 25 or penalites < 25 :
        if annees >= 5 and matchs > 55 :
            print("votre code de prime est 3")
        elif annees >=5 and matchs <= 55 :
            print("votre code de prime est 2")
        else :
            print("votre code de prime est 1")
    else :
            print("votre code de prime est 0")

#Partie B

a=None
b=None
c=None
d=None
e=None

def verification_prime (a,b,c,d,e):
    "demande les statistiques d'un joueur puis vérifie la prime, s'il en a"
    
    a=int(input("entrez le nombre de buts marques (le nombre doit être positif s'il vous plait): "))
    b=int(input("entrez le nombre d'aides recoltes (le nombre doit être positif s'il vous plait): "))
    c=int(input("entrez le nombre de penealites recues (le nombre doit être positif s'il vous plait): "))
    d=int(input("entrez le nombre d'annees dans cette equipe (le nombre doit être positif s'il vous plait): "))
    e=int(input("entrez le nombre de matchs joues (le nombre doit être positif s'il vous plait): "))

    while a < 0 or b < 0 or c < 0 or d < 0 or e < 0 :
           verification_prime(a,b,c,d,e)
           break
    if a > 0 or b > 0 or c > 0 or d > 0 or e > 0 :
        prime_joueur(a,b,c,d,e)

verification_prime (a,b,c,d,e)

          
            
                
    
